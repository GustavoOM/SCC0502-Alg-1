#ifndef UTIL_H
#define UTIL_H

#define ERRO -30000
#define TRUE 1
#define FALSE 0
typedef int boolean;

void converterInteiro(boolean valor);

#endif //UTIL_H
